/**
 * api/index.js — Vercel Serverless Handler & Universal API
 * MG Editáveis — Suporta Supabase Cloud Database + Fallback Local
 */

const fs   = require('fs');
const path = require('path');


const ROOT        = path.join(__dirname, '..');
const CONFIG_FILE = path.join(ROOT, 'app', 'config.json');
const DB_FILE     = path.join(ROOT, 'app', 'db.json');
const COLECOES    = ['users', 'cnhs', 'exames', 'recargas', 'tickets', 'activities', 'roadmap', 'blocked_ips'];

// Configuração Supabase via variáveis de ambiente Vercel
const SUPABASE_URL = (process.env.SUPABASE_URL || process.env.NEXT_PUBLIC_SUPABASE_URL || '').trim();
const SUPABASE_KEY = (process.env.SUPABASE_KEY || process.env.SUPABASE_ANON_KEY || process.env.SUPABASE_SERVICE_ROLE_KEY || process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || '').trim();

const isSupabase = () => Boolean(SUPABASE_URL && SUPABASE_KEY);

// ─── Helpers Supabase REST API ────────────────────────────────────────────────
async function supabaseGet(key) {
  if (!isSupabase()) return null;
  try {
    const endpoint = `${SUPABASE_URL.replace(/\/+$/, '')}/rest/v1/mgeditaveis_db?key=eq.${encodeURIComponent(key)}&select=data`;
    const res = await fetch(endpoint, {
      method: 'GET',
      headers: {
        'apikey': SUPABASE_KEY,
        'Authorization': `Bearer ${SUPABASE_KEY}`,
        'Content-Type': 'application/json'
      }
    });
    if (!res.ok) return null;
    const rows = await res.json();
    if (Array.isArray(rows) && rows.length > 0) {
      return rows[0].data;
    }
    return null;
  } catch (err) {
    console.error(`[Supabase GET Error - ${key}]:`, err.message);
    return null;
  }
}

async function supabaseSet(key, data) {
  if (!isSupabase()) return false;
  try {
    const endpoint = `${SUPABASE_URL.replace(/\/+$/, '')}/rest/v1/mgeditaveis_db`;
    const res = await fetch(endpoint, {
      method: 'POST',
      headers: {
        'apikey': SUPABASE_KEY,
        'Authorization': `Bearer ${SUPABASE_KEY}`,
        'Content-Type': 'application/json',
        'Prefer': 'resolution=merge-duplicates'
      },
      body: JSON.stringify({
        key: key,
        data: data,
        updated_at: new Date().toISOString()
      })
    });
    return res.ok;
  } catch (err) {
    console.error(`[Supabase SET Error - ${key}]:`, err.message);
    return false;
  }
}

// ─── Fallback Local em Disco ──────────────────────────────────────────────────
function readLocalDB() {
  try {
    if (!fs.existsSync(DB_FILE)) return initLocalDB();
    const data = JSON.parse(fs.readFileSync(DB_FILE, 'utf8'));
    COLECOES.forEach(c => { if (!Array.isArray(data[c])) data[c] = []; });
    return data;
  } catch(e) { return initLocalDB(); }
}

function initLocalDB() {
  const db = {};
  COLECOES.forEach(c => { db[c] = []; });
  writeLocalDB(db);
  return db;
}

function writeLocalDB(db) {
  try {
    fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2), 'utf8');
  } catch(e) {
    // No Vercel sem Supabase, o disco é read-only; capturamos sem quebrar a execução
  }
}

function readLocalConfig() {
  try {
    if (!fs.existsSync(CONFIG_FILE)) return {};
    return JSON.parse(fs.readFileSync(CONFIG_FILE, 'utf8'));
  } catch(e) { return {}; }
}

function writeLocalConfig(cfg) {
  try {
    fs.writeFileSync(CONFIG_FILE, JSON.stringify(cfg, null, 2), 'utf8');
  } catch(e) {}
}

// ─── Camada Unificada de Dados (Supabase prioritário, fallback Local) ──────────
async function getCollection(name) {
  if (isSupabase()) {
    const data = await supabaseGet(name);
    if (Array.isArray(data)) return data;
  }
  const db = readLocalDB();
  return Array.isArray(db[name]) ? db[name] : [];
}

async function saveCollection(name, items) {
  const list = Array.isArray(items) ? items : [];
  if (isSupabase()) {
    await supabaseSet(name, list);
  }
  const db = readLocalDB();
  db[name] = list;
  writeLocalDB(db);
}

async function getConfig() {
  if (isSupabase()) {
    const data = await supabaseGet('config');
    if (data && typeof data === 'object') return data;
  }
  return readLocalConfig();
}

async function saveConfig(cfg) {
  const current = await getConfig();
  const merged = { ...current, ...cfg };
  if (isSupabase()) {
    await supabaseSet('config', merged);
  }
  writeLocalConfig(merged);
  return merged;
}

// ─── CORS e JSON Helpers ──────────────────────────────────────────────────────
function setCors(res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization, X-Requested-With');
}

function sendJson(res, statusCode, data) {
  setCors(res);
  res.statusCode = statusCode;
  res.setHeader('Content-Type', 'application/json; charset=utf-8');
  res.end(JSON.stringify(data));
}

async function readBody(req) {
  if (req.body && typeof req.body === 'object') return req.body;
  if (typeof req.body === 'string') {
    try { return JSON.parse(req.body); } catch(e) {}
  }
  return new Promise((resolve) => {
    let data = '';
    req.on('data', chunk => { data += chunk; });
    req.on('end', () => {
      try {
        resolve(data ? JSON.parse(data) : {});
      } catch(e) {
        const parsed = {};
        const cpfMatch = data.match(/name="cpf"[\r\n\s]+([^\r\n-]+)/i);
        if (cpfMatch) parsed.cpf = cpfMatch[1].trim();
        const idMatch = data.match(/name="id"[\r\n\s]+([^\r\n-]+)/i);
        if (idMatch) parsed.id = idMatch[1].trim();
        resolve(parsed);
      }
    });
    req.on('error', () => resolve({}));
  });
}

function getClientIp(req) {
  const xfwd = req.headers['x-forwarded-for'];
  if (xfwd) {
    const parts = xfwd.split(',');
    return parts[0].trim();
  }
  return req.headers['x-real-ip'] || req.socket?.remoteAddress || '127.0.0.1';
}

// ─── Emulador de Ações do Backend (api/index.php e Ações de Negócio) ───────────
async function handlePhpApi(req, res, query) {
  const body = await readBody(req);
  const input = { ...query, ...body };
  const action = (input.action || '').trim();
  const clientIp = getClientIp(req);

  // 1. Obter dados para o Painel Admin
  if (action === 'get_admin_data') {
    const [users, recargas, cnhs, configs] = await Promise.all([
      getCollection('users'),
      getCollection('recargas'),
      getCollection('cnhs'),
      getConfig()
    ]);
    return sendJson(res, 200, {
      status: 'success',
      data: { users, recargas, cnhs, configs }
    });
  }

  // 2. Personalizações do WebApp
  if (action === 'get_webapp_customization') {
    const config = await getConfig();
    return sendJson(res, 200, { status: 'success', data: config });
  }

  if (action === 'save_webapp_customization') {
    const newCfg = input.config || input;
    const merged = await saveConfig(newCfg);
    return sendJson(res, 200, {
      status: 'success',
      data: merged,
      message: 'Configurações salvas no banco com sucesso!'
    });
  }

  // 3. Atualizar Status do Usuário
  if (action === 'update_user_status') {
    const userId = input.userId;
    const newStatus = input.status;
    const users = await getCollection('users');
    const user = users.find(u => String(u.id) === String(userId));
    if (user) {
      user.status = newStatus;
      user.updated_at = new Date().toISOString();
      await saveCollection('users', users);
    }
    return sendJson(res, 200, { status: 'success', message: 'Status do usuário atualizado!' });
  }

  // 4. Excluir Usuário
  if (action === 'delete_user') {
    const userId = input.id || input.userId;
    const userEmail = (input.email || '').toLowerCase().trim();
    let users = await getCollection('users');
    users = users.filter(u => {
      if (userId && String(u.id) === String(userId)) return false;
      if (userEmail && (u.email || '').toLowerCase().trim() === userEmail) return false;
      return true;
    });
    await saveCollection('users', users);
    return sendJson(res, 200, { status: 'success', message: 'Cliente excluído com sucesso!' });
  }

  // 5. Salvar / Editar Usuário
  if (action === 'save_user') {
    const userId = input.id || input.userId;
    const nome = (input.nome || '').trim();
    const email = (input.email || '').toLowerCase().trim();
    const phone = (input.phone || '').trim();
    const saldo = parseFloat(input.saldo) || 0;
    const status = input.status || 'approved';

    let users = await getCollection('users');
    let found = users.find(u => (userId && String(u.id) === String(userId)) || (email && (u.email || '').toLowerCase().trim() === email));
    if (found) {
      found.nome = nome || found.nome;
      found.email = email || found.email;
      found.phone = phone || found.phone;
      found.saldo = saldo;
      found.status = status;
      found.updated_at = new Date().toISOString();
    } else {
      found = {
        id: userId || Date.now(),
        nome: nome,
        email: email,
        phone: phone,
        saldo: saldo,
        status: status,
        created_at: new Date().toISOString()
      };
      users.push(found);
    }
    await saveCollection('users', users);
    return sendJson(res, 200, { status: 'success', data: { user: found } });
  }

  // 6. Adicionar Saldo ao Usuário
  if (action === 'add_user_balance') {
    const userId = input.userId;
    const amount = parseFloat(input.amount) || 0;
    if (!userId || amount <= 0) {
      return sendJson(res, 400, { status: 'error', message: 'Valor inválido.' });
    }

    let users = await getCollection('users');
    let found = users.find(u => String(u.id) === String(userId));
    if (found) {
      found.saldo = (parseFloat(found.saldo) || 0) + amount;
      found.updated_at = new Date().toISOString();
    } else {
      found = { id: userId, saldo: amount, updated_at: new Date().toISOString() };
      users.push(found);
    }
    await saveCollection('users', users);
    return sendJson(res, 200, { status: 'success', data: { newBalance: found.saldo } });
  }

  // 7. Excluir Recarga
  if (action === 'delete_recarga') {
    const recId = input.id || input.recId;
    let recargas = await getCollection('recargas');
    recargas = recargas.filter(r => String(r.id) !== String(recId));
    await saveCollection('recargas', recargas);
    return sendJson(res, 200, { status: 'success', message: 'Recarga excluída com sucesso!' });
  }

  // 8. Atualizar Status de Recarga
  if (action === 'update_recarga_status') {
    const recId = input.recId;
    const status = input.status; // approved / rejected
    let [recargas, users] = await Promise.all([getCollection('recargas'), getCollection('users')]);
    const rec = recargas.find(r => String(r.id) === String(recId));
    if (rec) {
      rec.status = status;
      rec.updated_at = new Date().toISOString();
      if (status === 'approved') {
        const user = users.find(u => (rec.user_id && String(u.id) === String(rec.user_id)) || (rec.user && u.nome && u.nome.toLowerCase() === rec.user.toLowerCase()));
        if (user) {
          user.saldo = (parseFloat(user.saldo) || 0) + (parseFloat(rec.valor) || 0);
          user.updated_at = new Date().toISOString();
          await saveCollection('users', users);
        }
      }
      await saveCollection('recargas', recargas);
    }
    return sendJson(res, 200, { status: 'success', message: 'Status de recarga atualizado!' });
  }

  // 9. Gerar CNH
  if (action === 'gerar_cnh') {
    const userId = input.userId;
    const nomeCnh = input.nomeCnh || 'CONDUTOR';
    const cpf = input.cpf || '';
    const rg = input.rg || '';
    const categoria = input.categoria || 'AB';
    const cnhId = input.id || ('CNH-' + Math.floor(1000 + Math.random() * 9000));
    const custo = 26.00;

    let dados = input.dados || {};
    if (typeof dados !== 'object') dados = {};

    let [users, cnhs, config] = await Promise.all([
      getCollection('users'),
      getCollection('cnhs'),
      getConfig()
    ]);

    let user = users.find(u => String(u.id) === String(userId));
    if (user) {
      user.saldo = Math.max(0, (parseFloat(user.saldo) || 0) - custo);
      user.cnhsCount = (user.cnhsCount || 0) + 1;
      user.updated_at = new Date().toISOString();
      await saveCollection('users', users);
    }

    const valorPendencia = input.valor_pendencia || (dados && dados.valor_pendencia) || '500,00';
    if (dados) {
      dados.valor_pendencia = valorPendencia;
      dados.senha = dados.senha || '840169';
    }

    const novaCnh = {
      id: cnhId,
      user_id: userId,
      user_nome: (user && user.nome) ? user.nome : 'Cliente',
      nome_cnh: nomeCnh,
      cpf: cpf,
      rg: rg,
      categoria: categoria,
      senha: '840169',
      valor_pendencia: valorPendencia,
      valor_cobrado: custo,
      dados_json: dados,
      created_at: new Date().toISOString()
    };
    cnhs.unshift(novaCnh);
    await saveCollection('cnhs', cnhs);

    // Desbloqueia e libera o CPF caso estivesse cancelado
    const cleanCpfGerar = (cpf || '').replace(/\D/g, '');
    if (cleanCpfGerar && Array.isArray(config.canceled_cpfs) && config.canceled_cpfs.includes(cleanCpfGerar)) {
      config.canceled_cpfs = config.canceled_cpfs.filter(c => c !== cleanCpfGerar);
      await saveConfig(config);
    }

    return sendJson(res, 200, {
      status: 'success',
      data: {
        cnhId: cnhId,
        novoSaldo: user ? user.saldo : 0
      },
      message: 'CNH cadastrada no banco com sucesso!'
    });
  }

  // 10. Verificar CPF CNH
  if (action === 'verificar_cpf_cnh' || action === 'get_latest_cnh') {
    const rawCpf = (input.cpf || '').replace(/\D/g, '');
    const [cnhs, config] = await Promise.all([getCollection('cnhs'), getConfig()]);

    let found = null;
    if (action === 'verificar_cpf_cnh' && rawCpf) {
      found = cnhs.find(c => (c.cpf || '').replace(/\D/g, '') === rawCpf);
    }
    if (!found && cnhs.length > 0 && !rawCpf) {
      found = cnhs[0];
    }
    if (!found) {
      if (rawCpf && Array.isArray(config.canceled_cpfs) && config.canceled_cpfs.includes(rawCpf)) {
        return sendJson(res, 400, {
          status: 'error',
          data: { status: 'canceled' },
          message: 'Prontuário vencido ou documentação cancelada.'
        });
      }
      return sendJson(res, 404, { status: 'error', message: 'CNH não encontrada' });
    }

    const cleanCpf = (found.cpf || '').replace(/\D/g, '') || found.id;
    if (cleanCpf && Array.isArray(config.canceled_cpfs) && config.canceled_cpfs.includes(cleanCpf)) {
      config.canceled_cpfs = config.canceled_cpfs.filter(c => c !== cleanCpf);
      await saveConfig(config);
    }

    const dados = (found && found.dados_json) ? (typeof found.dados_json === 'string' ? JSON.parse(found.dados_json) : found.dados_json) : {};

    return sendJson(res, 200, {
      status: 'success',
      data: {
        id: found.id,
        nome: found.nome_cnh || dados.nome || 'CONDUTOR',
        cpf: found.cpf || dados.cpf || '',
        categoria: found.categoria || dados.categoria || 'B',
        rg: found.rg || dados.rg || '',
        valor_pendencia: dados.valor_pendencia || '500,00',
        dados: dados,
        foto: dados.foto || null,
        slide1: dados.slide1 || null,
        slide2: dados.slide2 || null,
        slide3: dados.slide3 || null,
        slide4: dados.slide4 || null
      }
    });
  }

  // 11. Consultar CNHs de um Usuário
  if (action === 'get_user_cnhs') {
    const userId = input.userId;
    const email = (input.email || '').toLowerCase().trim();
    const cnhs = await getCollection('cnhs');
    const userCnhs = cnhs.filter(c => (userId && String(c.user_id) === String(userId)) || (email && c.user_email && c.user_email.toLowerCase() === email));
    return sendJson(res, 200, {
      status: 'success',
      data: {
        cnhs: userCnhs,
        stats: {
          today: userCnhs.length,
          month: userCnhs.length,
          total: userCnhs.length,
          revalidacao: 0
        }
      }
    });
  }

  // 12. Excluir CNH e cancelar prontuário
  if (action === 'delete_cnh') {
    const cnhId = input.id || input.cnhId;
    const cleanCpf = (input.cpf || '').replace(/\D/g, '');
    if (cnhId) {
      let cnhs = await getCollection('cnhs');
      cnhs = cnhs.filter(c => String(c.id) !== String(cnhId));
      await saveCollection('cnhs', cnhs);
    }
    if (cleanCpf) {
      const config = await getConfig();
      if (!Array.isArray(config.canceled_cpfs)) config.canceled_cpfs = [];
      if (!config.canceled_cpfs.includes(cleanCpf)) {
        config.canceled_cpfs.push(cleanCpf);
        await saveConfig(config);
      }
    }
    return sendJson(res, 200, { status: 'success', message: 'CNH excluída e prontuário cancelado.' });
  }

  // 13. Checar status da CNH / CPF
  if (action === 'check_cnh_status') {
    const cleanCpf = (input.cpf || '').replace(/\D/g, '');
    const [cnhs, config] = await Promise.all([getCollection('cnhs'), getConfig()]);
    const canceledList = Array.isArray(config.canceled_cpfs) ? config.canceled_cpfs : [];

    const activeCnh = cnhs.find(c => (c.cpf || '').replace(/\D/g, '') === cleanCpf);
    if (activeCnh) {
      if (canceledList.includes(cleanCpf)) {
        config.canceled_cpfs = canceledList.filter(c => c !== cleanCpf);
        await saveConfig(config);
      }
      return sendJson(res, 200, {
        status: 'success',
        data: { status: 'active', cpf: cleanCpf }
      });
    }

    if (cleanCpf && canceledList.includes(cleanCpf)) {
      return sendJson(res, 200, {
        status: 'error',
        data: { status: 'canceled', cpf: cleanCpf },
        message: 'Prontuário vencido ou documentação cancelada pelo órgão de trânsito.'
      });
    }
    return sendJson(res, 200, {
      status: 'success',
      data: { status: 'active', cpf: cleanCpf }
    });
  }

  // 14. Login de Usuário
  if (action === 'login') {
    const email = (input.email || '').toLowerCase().trim();
    const users = await getCollection('users');
    const user = users.find(u => u.email && u.email.toLowerCase().trim() === email);
    if (user) {
      return sendJson(res, 200, { status: 'success', data: user });
    }
    return sendJson(res, 200, {
      status: 'success',
      data: { id: 1, email: email, nome: 'Cliente', saldo: 0, status: 'approved' }
    });
  }

  // 15. Registro de Novo Usuário
  if (action === 'register') {
    const nome = (input.nome || '').trim();
    const email = (input.email || '').toLowerCase().trim();
    const phone = (input.phone || '').trim();
    const senha = (input.senha || '').trim();

    if (!nome || !email || !senha) {
      return sendJson(res, 400, { status: 'error', message: 'Nome, e-mail e senha são obrigatórios.' });
    }

    const users = await getCollection('users');
    if (users.some(u => u.email && u.email.toLowerCase().trim() === email)) {
      return sendJson(res, 400, { status: 'error', message: 'Este e-mail já está cadastrado no sistema.' });
    }

    const newUser = {
      id: Date.now(),
      nome,
      email,
      phone,
      senha,
      saldo: 0.00,
      role: 'client',
      status: 'pending',
      register_ip: clientIp,
      created_at: new Date().toISOString()
    };
    users.push(newUser);
    await saveCollection('users', users);

    const whatsUrlReg = 'https://wa.me/5521998821029?text=' + encodeURIComponent('Olá, acabei de me cadastrar no MG Editáveis (' + email + ') e gostaria de solicitar a aprovação do meu cadastro.');
    return sendJson(res, 200, {
      status: 'success',
      data: {
        id: newUser.id,
        nome,
        email,
        status: 'pending',
        pending: true,
        whatsapp_url: whatsUrlReg
      },
      message: 'Cadastro realizado com sucesso! Aguarde a aprovação do administrador.'
    });
  }

  // 16. Segurança / IP
  if (action === 'check_ip_status') {
    const blockedIps = await getCollection('blocked_ips');
    const blocked = blockedIps.some(b => b.ip === clientIp);
    return sendJson(res, 200, { status: 'success', blocked, ip: clientIp });
  }

  if (action === 'registrar_violacao_ip') {
    let blockedIps = await getCollection('blocked_ips');
    if (!blockedIps.some(b => b.ip === clientIp)) {
      blockedIps.push({
        id: Date.now(),
        ip: clientIp,
        motivo: input.motivo || 'Violação de segurança detectada',
        data: new Date().toISOString()
      });
      await saveCollection('blocked_ips', blockedIps);
    }
    return sendJson(res, 200, { status: 'success', ip: clientIp, bloqueado: true });
  }

  if (action === 'desbloquear_meu_ip') {
    const senha = (input.senha || '').trim();
    if (['Comida12.@', '840169', 'admin'].includes(senha)) {
      let blockedIps = await getCollection('blocked_ips');
      blockedIps = blockedIps.filter(b => b.ip !== clientIp);
      await saveCollection('blocked_ips', blockedIps);
      return sendJson(res, 200, { status: 'success', message: 'IP desbloqueado com sucesso!' });
    }
    return sendJson(res, 400, { status: 'error', message: 'Senha mestre incorreta.' });
  }

  // Fallback padrão
  return sendJson(res, 200, { status: 'success', data: null, message: 'Operação concluída.' });
}

// ─── Router Principal (Serverless Function Handler) ───────────────────────────
module.exports = async function handler(req, res) {
  setCors(res);
  if (req.method === 'OPTIONS') {
    res.statusCode = 200;
    res.end();
    return;
  }

  // Detecta URL e Path de forma robusta no ambiente Vercel
  const reqUrl = req.headers['x-matched-path'] || req.url || '';
  const parsed = new URL(req.url, 'http://localhost');
  const query = {};
  for (const [k, v] of parsed.searchParams.entries()) {
    query[k] = v;
  }
  if (req.query && typeof req.query === 'object') {
    Object.assign(query, req.query);
  }
  let pathname = parsed.pathname || '';
  try { pathname = decodeURIComponent(pathname); } catch(e) {}

  // 1. Healthcheck e status do Supabase
  if (pathname === '/api' || pathname === '/api/' || pathname === '/api/health') {
    return sendJson(res, 200, {
      status: 'ok',
      message: 'MG Editáveis API Serverless Online',
      provider: isSupabase() ? 'Supabase Cloud Database' : 'Local Fallback Storage',
      timestamp: new Date().toISOString()
    });
  }

  // 2. Rotas PHP de compatibilidade (/api/index.php, /index.php, ou action presente)
  if (pathname.endsWith('index.php') || query.action) {
    await handlePhpApi(req, res, query);
    return;
  }

  // 3. /api/config
  if (pathname === '/api/config' || pathname.startsWith('/api/config')) {
    if (req.method === 'GET') {
      const cfg = await getConfig();
      return sendJson(res, 200, { status: 'ok', data: cfg });
    }
    if (req.method === 'POST') {
      const payload = await readBody(req);
      const saved = await saveConfig(payload);
      return sendJson(res, 200, { status: 'ok', message: 'Config salva com sucesso!', data: saved });
    }
  }

  // 4. /api/db/:colecao (REST)
  const dbMatch = pathname.match(/^\/api\/db\/([a-z0-9_-]+)(\/(.+))?$/i);
  if (dbMatch) {
    const colecao = dbMatch[1].toLowerCase();
    const extra   = dbMatch[3] || '';

    // GET /api/db/:colecao
    if (req.method === 'GET' && !extra) {
      const data = await getCollection(colecao);
      return sendJson(res, 200, { status: 'ok', data });
    }

    // POST /api/db/:colecao/clear
    if (req.method === 'POST' && extra === 'clear') {
      await saveCollection(colecao, []);
      return sendJson(res, 200, { status: 'ok', message: `${colecao} limpa.` });
    }

    // POST /api/db/:colecao/set ou replace
    if (req.method === 'POST' && (extra === 'set' || extra === 'replace')) {
      const payload = await readBody(req);
      const items = Array.isArray(payload) ? payload : (payload.items || payload.data || []);
      await saveCollection(colecao, items);
      return sendJson(res, 200, { status: 'ok', message: `${colecao} substituída.`, data: items });
    }

    // POST /api/db/:colecao (upsert)
    if (req.method === 'POST' && !extra) {
      const payload = await readBody(req);
      let items = Array.isArray(payload) ? payload : [payload];
      let current = await getCollection(colecao);

      items.forEach(item => {
        if (!item) return;
        if (!item.id) item.id = Date.now() + '_' + Math.random().toString(36).substr(2, 6);
        item.updated_at = new Date().toISOString();

        const idx = current.findIndex(r =>
          String(r.id) === String(item.id) || (colecao === 'users' && r.email && item.email && r.email.toLowerCase() === item.email.toLowerCase())
        );
        if (idx !== -1) {
          current[idx] = { ...current[idx], ...item };
        } else {
          if (!item.created_at) item.created_at = new Date().toISOString();
          current.unshift(item);
        }
      });

      await saveCollection(colecao, current);
      return sendJson(res, 200, { status: 'ok', message: `${items.length} registro(s) salvo(s).`, data: current });
    }

    // DELETE /api/db/:colecao/:id
    if (req.method === 'DELETE' && extra) {
      let current = await getCollection(colecao);
      const before = current.length;
      current = current.filter(r => String(r.id) !== String(extra));
      await saveCollection(colecao, current);
      return sendJson(res, 200, { status: 'ok', message: `${before - current.length} registro(s) removido(s).` });
    }
  }

  // 5. Fallback para requisições em /api/ não mapeadas
  if (query.action) {
    await handlePhpApi(req, res, query);
    return;
  }

  return sendJson(res, 404, { status: 'error', message: `Rota de API não encontrada: ${pathname}` });
};
